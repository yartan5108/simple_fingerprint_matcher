
import os, sys
import cv2
from matplotlib import pyplot as plt
import numpy as np
from scipy.stats import norm
from skimage.morphology import convex_hull_image
from scipy.spatial.distance import cdist

from file_reader import fmr_reader
from Params import ParamsAll

import time
import concurrent.futures


global similarity_thresh
similarity_thresh = 0.3

class Cylinder_Generator:

    def  __init__(self, *args):

        if args.__len__() != 0:
            self.img = args[0]
            self.data = np.array( args[1] )
        else:
            self.img = []
            self.data = []

        self.Plot_on = 0
        self.Nd = 6
        self.Ns = 16
        self.R = 70
        self.sigma_S = 10
        self.sigmaD = 2 * np.pi / 9
        self.mu = 0.005
        self.tao = 1000
        self.muP = 20
        self.taoP = 2 / 5
        self.minNp = 4
        self.maxNp = 15 # 12
        self.mu1P = 5
        self.tao1P = -8 / 5
        self.mu2P = np.pi / 12
        self.tao2P = -30
        self.mu3P = np.pi / 12
        self.tao3P = -30
        self.delta_S = 2 * self.R / self.Ns
        self.delta_D = (1 / self.Nd) * 2 * np.pi

        if self.data.__len__() != 0:
            binary_image = 0 * self.img
            for iter in np.arange(0, self.data.shape[0]):
                x_m, y_m, angle = self.data[iter, :]
                binary_image[ y_m, x_m ] = 1
            self.convex_hull = convex_hull_image( binary_image )
            kernel = np.ones( (10,10), np.uint8 )
            tmp_convex = cv2.dilate( np.uint8(self.convex_hull), kernel, iterations=1 )
            self.convex_hull = tmp_convex

        k = np.arange(1, self.Nd + 1) - 0.5
        self.delta_phi = 180 * (-np.pi + k*self.delta_D ) * (1/np.pi)

    def compute_phi(self):

        data = self.data
        data[:, 2] = data[:,2] * 1.41  # multiply angle by 1.41

        cylinder = {}

        if self.Plot_on:
            plt.figure(1)
            plt.imshow(self.img, cmap='gray')

        counter = 0

        for iter in np.arange(0,data.shape[0]):

            y_m, x_m, angle = data[ iter, : ]

            angle = np.pi * (angle/180)
            tmp_mat = np.array( [ [np.cos(angle), -1*np.sin(angle)], [np.sin(angle), np.cos(angle)] ] )

            pMat = np.zeros((self.Ns, self.Ns, 2))

            if self.Plot_on:
                plt.plot( x_m, y_m, 'g.')

            for i in np.arange(0,self.Ns):
                for j in np.arange(0,self.Ns):
                    tmp = np.array( [ x_m, y_m ] ).T
                    tmp = tmp.astype(float)

                    tmp2 = self.delta_S * tmp_mat
                    tmp3 = np.array( [ [ (i+1)-(0.5*(self.Ns+1))], [ (j+1)-(0.5*(self.Ns+1))] ] )
                    tmp = tmp + np.matmul( tmp2, tmp3 ).T

                    pMat[i, j, :] = [ np.max( (tmp[0,0], 1) ), np.max( (tmp[0,1], 1) ) ]

                    if self.Plot_on:
                        if np.mod(i+j,5)==2:
                            plt.plot( pMat[i, j, 0], pMat[i, j, 1], 'r.' )

            NeighborMat, indis_list, Pmat, validity = self.refine_pMat( pMat, [x_m, y_m] )
            indis_lists =  np.array( indis_list )

            check_cell_count = np.sum( validity[:] ) <= (self.Ns * self.Ns * 0.5)
            check_minutiae_count = np.setdiff1d( np.unique( indis_lists ), iter ).shape[0] <= 1

            if (check_cell_count or check_minutiae_count):
                print(' {}, {}, {} :  Skip this minutiae, too few minutiae detected.\n'.format( x_m, y_m, angle) )
                continue

            # Compute C_ijk term for the cylinder.
            Cmat = self.compute_Cmat( iter, data, angle, NeighborMat, Pmat )
            c_v, v_v = self.vectorize_Cmat( Cmat, validity)

            cylinder[ (counter,0) ] = np.array(c_v).ravel()
            cylinder[ (counter,1) ] = np.array(v_v).ravel()
            cylinder[ (counter,2) ] = [ x_m, y_m, angle ]
            counter+=1

        print('Cylinder Generator:..')
        return cylinder, counter

    def refine_pMat(self, pMat, xtest ):

        Pmat = pMat
        Validity = np.ones( (self.Ns, self.Ns) )

        for i in np.arange(0, self.Ns):
            for j in np.arange(0, self.Ns):

                tmp1 = np.round( Pmat[i, j, 0] ).astype(int)
                tmp2 = np.round( Pmat[i, j, 1] ).astype(int)

                if tmp1<0 or tmp2<0:
                    Pmat[i, j, :] = 0
                    Validity[i, j] = 0

                try:
                    if  tmp1< self.convex_hull.shape[0] and tmp2 < self.convex_hull.shape[1]:
                        if self.convex_hull[tmp1, tmp2 ] == 0:
                            Validity[i,j] = 0

                        v1 = Pmat[i,j,:]
                        v2 = xtest

                        if np.sqrt( (v1[0]-v2[0])**2 + (v1[1]-v2[1])**2 ) >= self.R :
                            Pmat[i,j,:] = 0
                            Validity[i,j] = 0
                except:
                    print('Problem var..')

        NeighborMat, indis_list = self.Compute_NeighborHood( Pmat, Validity )
        return NeighborMat, indis_list, Pmat, Validity

    def Compute_NeighborHood( self, Pmat, validity ):

         indis_list = []
         indis_list = np.asarray( indis_list )
         NeighborMat = {}
         tmp_data = self.data[:, 0:2]
         for i in np.arange(0,Pmat.shape[0]):
            for j in np.arange(0,Pmat.shape[1]):
                if ( Pmat[i,j,0]!=0 and Pmat[i,j,1]!=0 ):
                    if validity[i, j] != 0:
                        v1 = Pmat[i, j, :]
                        ind =  np.where( cdist( tmp_data, np.fliplr([v1]) ) <= 3*self.sigma_S )
                        NeighborMat[(i, j)] = np.asarray( ind[0] )
                        indis_list = np.append(indis_list,ind[0])
         return NeighborMat, indis_list

    def compute_Cmat( self, iter, data, angle, NeighborMat, Pmat ):

        Cmat = np.zeros( (self.Ns, self.Ns, self.Nd) )
        if self.Plot_on:
           plt.plot( data(iter, 1), data(iter, 2), 'r.' )

        for i in np.arange(0, self.Ns):
            for j in np.arange(0, self.Ns):
               tmp_cell_loc = Pmat[i, j,: ]

               try:
                  tmp_neigh = np.setdiff1d( NeighborMat[(i, j)], iter )
               except:
                  continue

               if tmp_neigh.any():
                   for k in np.arange(0, self.delta_phi.shape[0]):
                       sum_tmp = 0
                       for vals in tmp_neigh:
                           if vals:
                               tmp_spatial = self.compute_spatial_dist( data[vals, 0:2], Pmat[i,j,:] )
                               tmp_directional = self.compute_directional_dist( angle, self.delta_phi[k], data[vals, 2] )

                           if vals:
                               sum_tmp = sum_tmp + tmp_spatial * tmp_directional

                       Cmat[i,j,k] = self.compute_Phi2(sum_tmp)
        return Cmat

    def compute_spatial_dist(self,a,b):
        dist_val = cdist( np.fliplr([a]), np.array([b]) )
        out = (1/(self.sigma_S * np.sqrt(2 * np.pi))) * np.exp( -0.5 * (dist_val / self.sigma_S)**2 )
        return out

    def compute_directional_dist(self, minutia_angle, delta_phi, test_point ):
        d_theta = self.directional_difference( minutia_angle*(180/np.pi), test_point )
        d_phi = self.directional_difference( delta_phi, d_theta )
        g_d = self.compute_gaussian( d_phi )
        return g_d

    def directional_difference(self, term1, term2):
        if abs( term1 - term2) < 180:
            d_phi = term1 - term2
        elif (term1 - term2) <= -180:
            d_phi = 360 + (term1 - term2)
        elif(term1 - term2) >= 180:
            d_phi = -360 + (term1 - term2)
        return d_phi

    def compute_gaussian(self, alpha):
        delta_subtract = self.delta_D*57 # change radian to degrees
        alpha_int = (1/180)*np.array([ np.array(alpha) - np.array(delta_subtract)/2, np.array(alpha) + np.array(delta_subtract)/2]) # convert back to radians.
        p = norm.cdf( alpha_int, loc = 0, scale = self.sigmaD )
        out = p[1] - p[0]
        return out

    def compute_Phi2(self,v):
        out = 1. / (1 + np.exp( -1* self.tao  * (v - self.mu)) )
        return out

    def vectorize_Cmat(self, Cmat, validity ):
        c_vec, v_vec = [], []
        for iterx in np.arange(0, Cmat.shape[2] ):
            tmp = Cmat[ :, :, iterx ]
            tmp2 = validity
            c_vec.append( np.ravel(tmp) )
            v_vec.append( np.ravel(tmp2) )
        return c_vec, v_vec

def pairwise_similarity( cy1, counter_cy1, cy2, counter_cy2 ):
    global param
    score_mat = np.zeros( (counter_cy1, counter_cy2) )
    for iter_m1 in np.arange( 0, counter_cy1 ):
        for iter_m2 in np.arange( 0, counter_cy2 ):
            a, a_2 = cy1[(iter_m1, 0)], cy1[(iter_m1, 1)]
            b, b_2 = cy2[(iter_m2, 0)], cy2[(iter_m2, 1)]
            c_vec_ab, c_vec_ba = cvec_ab( a, a_2, b, b_2, param['Ns'], param['Nd'] )
            tmp = (c_vec_ab - c_vec_ba)
            tmp2 = np.linalg.norm(tmp) / ( np.linalg.norm(c_vec_ab) + np.linalg.norm(c_vec_ba) )
            score_mat[iter_m1, iter_m2] = 1 - tmp2
    return score_mat

def cvec_ab( a, a_2, b, b_2, Ns, Nd ):

    Nc = Ns * Ns * Nd
    c_vec_ab = np.zeros( Nc )
    c_vec_ba = np.zeros( Nc )

    indis_overlap = np.where( np.multiply( np.array(a_2), np.array(b_2) )> 0 )
    c_vec_ab[indis_overlap] = a[indis_overlap]
    c_vec_ba[indis_overlap] = b[indis_overlap]

    return c_vec_ab, c_vec_ba

def SimilarityScore( score, numSeeds ):
    indis_pair = []
    score_vals = []
    global similarity_thresh
    score[np.isnan(score)] = 0

    for iter in np.arange(1,numSeeds):
       max_elem = np.max( score[:] )
       if max_elem>similarity_thresh:
           [row, col] = np.where( score == max_elem )
           score[ :, col[0] ] = 0
           score[ row[0], : ] = 0
           indis_pair.append( [ row[0], col[0] ] )
           score_vals.append( max_elem )
       else:
           continue
    return indis_pair, score_vals

def compute_MinNo( Na, Nb ):
    global param
    min_Nab = np.min( (Na, Nb) )
    out = 1./( 1 + np.exp( -1*param['muP']*( min_Nab - param['taoP'] ) ) )
    difference = ( param['maxNp'] - param['minNp'] )
    out = param['minNp'] + round( out*difference )
    return out

def directional_difference( term1, term2, deg_flag_on):
    if deg_flag_on:
        term1 = term1*(180/np.pi)
        term2 = term2*(180/np.pi)

    if abs(term1 - term2) < 180:
        d_phi = term1 - term2
    elif (term1 - term2) <= -180:
        d_phi = 360 + (term1 - term2)
    elif (term1 - term2) >= 180:
        d_phi = -360 + (term1 - term2)
    return d_phi

def compute_LLS_Phi( d1, d2, d3 ):
    global param
    out1 = 1./(1+np.exp(-1*param['tao1P'] *( d1 - param['mu1P'] )))
    out2 = 1./(1+np.exp(-1*param['tao2P'] *( d2 - param['mu2P'] )))
    out3 = 1./(1+np.exp(-1*param['tao3P'] *( d3 - param['mu3P'] )))
    out = out1*out2*out3
    return out

def LSS_relaxation( cylinder_m1, cylinder_m2, indis_pair, numSeeds, score_vals, out ):
    ''' Bulunan Pairlerde bulunan noktaları göz önüne alıp, geri kalanını çıkarıyoruz.'''

    template_A = []
    template_B = []
    for iterator in np.arange(0,numSeeds):
        tmp = cylinder_m1[ (indis_pair[iterator][0], 2) ]
        template_A.append( tmp )
        tmp = cylinder_m2[ (indis_pair[iterator][1], 2) ]
        template_B.append( tmp )

    p_tk = np.zeros( ( template_A.__len__(), template_A.__len__() ) )

    for iterx in np.arange( 0, template_A.__len__() ):
        for itery in np.arange( 0, template_A.__len__() ):
            if iterx != itery:
                tmp_t1 = template_A[iterx]
                tmp_t2 = template_A[itery]

                tmp_k1 = template_B[iterx]
                tmp_k2 = template_B[itery]

                # Spatial Term...
                ds_Atk = cdist( [np.array(tmp_t1[0:2])], [np.array(tmp_t2[0:2])] )
                ds_Btk = cdist( [np.array(tmp_k1[0:2])], [np.array(tmp_k2[0:2])] )
                d1_term = np.abs(ds_Atk - ds_Btk)

                # Angular Term...
                d_theta_A = directional_difference( tmp_t1[2], tmp_t2[2], 1 )
                d_theta_B = directional_difference( tmp_k1[2], tmp_k2[2], 1 )
                d2_term = np.abs(directional_difference(d_theta_A, d_theta_B, 0))

                # Radial Term...
                theta_m1 = tmp_t1[2]
                dR_m1 = np.arctan2( tmp_t1[0] - tmp_t2[0], tmp_t2[1] - tmp_t1[1] )
                dR_m1_term = directional_difference(theta_m1, dR_m1, 1)
                theta_m2 = tmp_k1[2]
                dR_m2 = np.arctan2( tmp_k1[0] - tmp_k2[0], tmp_k2[1] - tmp_k1[1] )
                dR_m2_term = directional_difference(theta_m2, dR_m2, 1)
                d3_term = abs(directional_difference(dR_m1_term, dR_m2_term, 0))

                p_tk[iterx, itery] = compute_LLS_Phi( d1_term, d2_term / 180, d3_term / 180 )

    # Eq.(25) iteration...
    w_R = 0.5
    Lambda_vec = np.array( score_vals )
    Lambda_vec_original = np.array( score_vals )
    Number_iter = 5
    for out_iter in np.arange(0, Number_iter):
       for iterxx in np.arange(0,template_A.__len__()):
           Lambda_k = np.array( Lambda_vec )
           Lambda_k[iterxx] = 0
           term1 = w_R * Lambda_vec[iterxx]
           term2 = (1 / (numSeeds - 1)) * np.matmul(p_tk[iterxx],Lambda_k)
           Lambda_vec[iterxx] = term1 + term2

    Lambda_Final_Values = []
    Lambda_Final_Indices = []
    Lambda_vec_tmp = np.divide(Lambda_vec, Lambda_vec_original)
    for iter in np.arange(0,out):
        max_ind = np.argmax( Lambda_vec_tmp, axis=0 )
        if Lambda_vec_tmp[max_ind] > 0.1:
            Lambda_Final_Values.append( Lambda_vec[max_ind] )
            Lambda_Final_Indices = [Lambda_Final_Indices, max_ind]
            Lambda_vec_tmp[max_ind] = 0
        else:
            Lambda_vec_tmp[max_ind] = 0
            continue

    if Lambda_Final_Indices:
        scoresum = sum(Lambda_Final_Values)
    else:
        scoresum = 0

    return scoresum

def main():

    Image_Path = './Db1_a/'
    FMR_path = './FM3_FVC2002DB1A/'

    global param
    param_tmp = Cylinder_Generator()
    param = ParamsAll( param_tmp )

    start_time = time.time()

    imagename = '1_1'
    data, im = fmr_reader( Image_Path, FMR_path, imagename)
    cylinder = Cylinder_Generator( im, data )
    cylinderV1, counterV1 = cylinder.compute_phi()

    imagename_test = '1_2'
    data_test, im_test = fmr_reader(Image_Path, FMR_path, imagename_test)
    cylinder_test = Cylinder_Generator( im_test, data_test )
    cylinder_testV1, counter_testV1  = cylinder_test.compute_phi()

    score = pairwise_similarity( cylinderV1, counterV1, cylinder_testV1, counter_testV1 )
    numSeeds = np.min( (cylinder.data.shape[0], cylinder_test.data.shape[0]) )
    indis_pair, score_vals = SimilarityScore(score, numSeeds)
    numSeeds = np.min( (numSeeds, np.array(indis_pair).shape[0]) )

    out = compute_MinNo( cylinder.data.shape[0],  cylinder_test.data.shape[0] )

    scoresum = LSS_relaxation( cylinderV1, cylinder_testV1, indis_pair, numSeeds, score_vals, out )

    end_time = time.time()
    print('Total Time: {} seconds'.format(  (end_time-start_time) ) )
    print('Score Val: {} '.format( scoresum ) )
    print( 'Cylinder {} x {} x {}'.format( cylinder.Nd, cylinder.Ns, cylinder.Ns ) )

    '''score_table_self[iter_outer, iter_out, iter_inner].name1 = imagename1
    score_table_self[iter_outer, iter_out, iter_inner].name2 = imagename2
    score_table_self[iter_outer, iter_out, iter_inner].value = scoresum'''

if __name__ == '__main__':

    main()
